<?php
error_reporting(0);
$username = $_GET['username'];
require("types.php");
$url="https://dumpor.com/search?query=$username";
$ig=str_get_html(file_get_contents($url));
 $pp=$ig->find("img[class='img-fluid w-100']",0)->src;

 $erh4n=$ig->find("a[class='btn btn-light m-1']",0);
  $followers=substr($erh4n,0,-13);

   $followers2=$ig->find("li[class='list__item']",1)->plaintext;
  $f_count=$ig->find("a[class='btn btn-light m-1']",1);

  $follower_count=substr($f_count,0,-13);
   $name=$ig->find("div[class='user__title']",0)->childNodes(0)->plaintext;
 $l_p_d=$ig->find("img[class='content__img']",0)->alt;
 $sonPost=$ig->find("img[class='content__img']",0)->src;


?>







