<?php 

$adminSifre="qwe&asd0";

$phpYolu="24c813924199da7805619d469148d9b1.php";//kayıt yolu




 ?>